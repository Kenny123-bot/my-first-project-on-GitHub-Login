<?php
require_once "functions.php";
$msg = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $user = fetch_user_by_email($email);
    if (!$user) {
        $msg = "Email not found.";
    } else if (!password_verify($password, $user['password'])) {
        $msg = "Wrong password.";
        log_activity($user['id'],'failed_login');
    } else if (!$user['is_verified']) {
        $msg = "Please verify your email first.";
    } else {
        session_start();
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['role'] = $user['role'];
        log_activity($user['id'],'login');
        header("Location: dashboard.php");
        exit;
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Login</title>
<link rel="stylesheet" href="assets/style.css"></head><body>
<div class="form-box">
  <h2>Login</h2>
  <p class="msg"><?=esc($msg)?></p>
  <form method="POST" novalidate>
    <input name="email" type="email" placeholder="Email" required>
    <input name="password" type="password" placeholder="Password" required>
    <button type="submit">Login</button>
    <p><a href="forgot.php">Forgot password?</a></p>
    <p><a href="register.php">Create account</a></p>
  </form>
</div>
<script src="assets/script.js"></script>
</body></html>
