
<?php
// DB
$db_host = 'localhost';
$db_user = 'root';
$db_pass = 'Nembabazi';
$db_name = 'githublogin_system';

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) die('DB connect error: '.$conn->connect_error);

// SITE URL (no trailing slash)
define('SITE_URL','http://localhost/login-system-pro');

// MAIL (use SMTP if possible)
// Either leave empty to use PHP mail() or fill SMTP details for PHPMailer
$mail_from = 'no-reply@example.com';
$mail_from_name = 'Login System';
$smtp = [
  'use_smtp' => false,
  'host' => '',
  'port' => 587,
  'username' => '',
  'password' => '',
  'secure' => 'tls' // 'tls' or 'ssl'
];

// Helpers
function esc($v){ return htmlspecialchars($v, ENT_QUOTES); }
?>
