<?php
require_once "functions.php";
$msg = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $email = trim($_POST['email']);
    $user = fetch_user_by_email($email);
    if (!$user) $msg = "If the email exists we'll send reset instructions.";
    else {
        $token = gen_token(16);
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
        $stmt = $conn->prepare("INSERT INTO password_resets (user_id, token, expires_at) VALUES (?,?,?)");
        $stmt->bind_param("iss", $user['id'], $token, $expires);
        if ($stmt->execute()) {
            $reset_link = SITE_URL."/reset.php?token={$token}&email=".urlencode($email);
            $subject = "Password reset";
            $body = "<p>Hi ".esc($user['name']).",</p><p>Reset: <a href='{$reset_link}'>Reset your password</a> (expires in 1 hour)</p>";
            send_mail_basic($email, $subject, $body);
            log_activity($user['id'],'password_reset_requested');
            $msg = "If the email exists we'll send reset instructions.";
        }
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Forgot</title>
<link rel="stylesheet" href="assets/style.css"></head><body>
<div class="form-box">
  <h2>Forgot Password</h2>
  <p class="msg"><?=esc($msg)?></p>
  <form method="POST"><input name="email" type="email" placeholder="Email" required><button>Send Reset Link</button></form>
  <p><a href="login.php">Back to login</a></p>
</div>
</body></html>
