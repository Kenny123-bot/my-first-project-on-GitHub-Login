<?php
require_once "functions.php";
$msg = "Invalid token.";

if (!empty($_GET['token']) && !empty($_GET['email'])) {
    $token = $_GET['token'];
    $email = $_GET['email'];

    $stmt = $conn->prepare("SELECT id,is_verified FROM users WHERE email=? AND verify_token=? LIMIT 1");
    $stmt->bind_param("ss",$email,$token);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();

    if ($res) {
        if ($res['is_verified']) {
            $msg = "Account already verified.";
        } else {
            $upd = $conn->prepare("UPDATE users SET is_verified=1, verify_token=NULL WHERE id=?");
            $upd->bind_param("i",$res['id']);
            if ($upd->execute()) {
                log_activity($res['id'],'verified_email');
                $msg = "Email verified successfully. You can login now.";
            }
        }
    } else {
        $msg = "Invalid or expired token.";
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Verify</title>
<link rel="stylesheet" href="assets/style.css"></head><body>
<div class="form-box"><h2>Verify Email</h2><p><?=esc($msg)?></p><p><a href="login.php">Login</a></p></div>
</body></html>
