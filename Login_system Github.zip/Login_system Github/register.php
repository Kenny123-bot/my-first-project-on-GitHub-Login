<?php
require_once "functions.php";
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($name) || empty($email) || empty($password)) {
        $message = "All fields required.";
    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Invalid email.";
    } else {
        if (fetch_user_by_email($email)) {
            $message = "Email already registered.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $token = gen_token(16);
            $stmt = $conn->prepare("INSERT INTO users (name, email, password, verify_token) VALUES (?,?,?,?)");
            $stmt->bind_param("ssss", $name, $email, $hash, $token);
            if ($stmt->execute()) {
                $user_id = $stmt->insert_id;
                $verify_link = SITE_URL."/verify.php?token={$token}&email=".urlencode($email);
                $subject = "Verify your account";
                $body = "<p>Hi ".esc($name).",</p>
                         <p>Click to verify: <a href='{$verify_link}'>Verify Account</a></p>";
                send_mail_basic($email, $subject, $body);
                log_activity($user_id, 'registered');
                $message = "Registered successfully. Check your email to verify your account.";
            } else {
                $message = "Registration failed.";
            }
        }
    }
}
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Register</title>
<link rel="stylesheet" href="assets/style.css"></head><body>
<div class="form-box">
  <h2>Create Account</h2>
  <p class="msg"><?= esc($message) ?></p>
  <form method="POST" novalidate>
    <input name="name" placeholder="Full name" required>
    <input name="email" type="email" placeholder="Email" required>
    <input name="password" type="password" placeholder="Password" required>
    <button type="submit">Register</button>
    <p><a href="login.php">Already have account? Login</a></p>
  </form>
</div>
<script src="assets/script.js"></script>
</body></html>
