<?php
session_start();
require_once "functions.php";
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }
$uid = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT action, ip, user_agent, created_at FROM activity_logs WHERE user_id=? ORDER BY created_at DESC LIMIT 50");
$stmt->bind_param("i",$uid);
$stmt->execute();
$res = $stmt->get_result();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Activity</title>
<link rel="stylesheet" href="assets/style.css"></head><body>
<div class="form-box">
  <h2>Your activity</h2>
  <ul>
  <?php while($r = $res->fetch_assoc()): ?>
    <li><?=esc($r['created_at']).' - '.esc($r['action']).' from '.esc($r['ip'])?></li>
  <?php endwhile; ?>
  </ul>
  <p><a href="dashboard.php">Back</a></p>
</div>
</body></html>
