<?php
session_start();
require_once "functions.php";
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }
$uid = $_SESSION['user_id'];
$msg = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name = trim($_POST['name']);
    if ($name) {
        $upd = $conn->prepare("UPDATE users SET name=? WHERE id=?");
        $upd->bind_param("si",$name,$uid);
        if ($upd->execute()) {
            $_SESSION['user_name'] = $name;
            $msg = "Profile updated.";
            log_activity($uid,'updated_profile');
        }
    }
}
$user = $conn->query("SELECT name,email,role,is_verified FROM users WHERE id=".$uid)->fetch_assoc();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Profile</title>
<link rel="stylesheet" href="assets/style.css"></head><body>
<div class="form-box">
  <h2>Profile</h2>
  <p class="msg"><?=esc($msg)?></p>
  <form method="POST">
    <input name="name" value="<?=esc($user['name'])?>" required>
    <input value="<?=esc($user['email'])?>" disabled>
    <button type="submit">Save</button>
  </form>
  <p><a href="dashboard.php">Back</a></p>
</div>
</body></html>
