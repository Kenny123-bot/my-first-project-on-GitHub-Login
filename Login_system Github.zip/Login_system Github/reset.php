<?php
require_once "functions.php";
$msg = '';
$showForm = false;

if (!empty($_GET['token']) && !empty($_GET['email'])) {
    $token = $_GET['token']; $email = $_GET['email'];
    $stmt = $conn->prepare("SELECT pr.id AS pr_id,pr.expires_at,u.id AS user_id FROM password_resets pr JOIN users u ON pr.user_id=u.id WHERE pr.token=? AND u.email=? AND pr.used=0 LIMIT 1");
    $stmt->bind_param("ss",$token,$email);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    if ($res && strtotime($res['expires_at']) > time()) {
        $showForm = true;
        $pr_id = $res['pr_id'];
        $user_id = $res['user_id'];
    } else {
        $msg = "Invalid or expired token.";
    }
}

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $pr_id = $_POST['pr_id'];
    $password = $_POST['password'];
    // fetch reset entry
    $stmt = $conn->prepare("SELECT user_id, expires_at, used FROM password_resets WHERE id=? LIMIT 1");
    $stmt->bind_param("i",$pr_id);
    $stmt->execute();
    $r = $stmt->get_result()->fetch_assoc();
    if ($r && !$r['used'] && strtotime($r['expires_at']) > time()) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $upd = $conn->prepare("UPDATE users SET password=? WHERE id=?");
        $upd->bind_param("si",$hash, $r['user_id']);
        if ($upd->execute()) {
            $mark = $conn->prepare("UPDATE password_resets SET used=1 WHERE id=?");
            $mark->bind_param("i",$pr_id); $mark->execute();
            log_activity($r['user_id'],'password_reset_completed');
            $msg = "Password reset successful. You can login now.";
            $showForm = false;
        } else {
            $msg = "Failed to reset.";
        }
    } else {
        $msg = "Invalid or expired token.";
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Reset</title>
<link rel="stylesheet" href="assets/style.css"></head><body>
<div class="form-box">
  <h2>Reset Password</h2>
  <p class="msg"><?=esc($msg)?></p>
  <?php if ($showForm): ?>
  <form method="POST">
    <input type="hidden" name="pr_id" value="<?=esc($pr_id)?>">
    <input name="password" type="password" placeholder="New password" required>
    <button type="submit">Set New Password</button>
  </form>
  <?php else: ?>
    <p><a href="login.php">Back to login</a></p>
  <?php endif; ?>
</div>
</body></html>
