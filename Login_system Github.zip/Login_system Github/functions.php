<?php
require_once "config.php";

function q($sql, $types=null, $params=null){
    global $conn;
    if (!$types) return $conn->query($sql);
    $stmt = $conn->prepare($sql);
    if ($params) $stmt->bind_param($types, ...$params);
    $stmt->execute();
    return $stmt;
}

function fetch_user_by_email($email){
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
    $stmt->bind_param("s",$email);
    $stmt->execute();
    $res = $stmt->get_result();
    return $res->fetch_assoc();
}

function send_mail_basic($to, $subject, $body){
    global $mail_from, $mail_from_name;
    $headers = "From: {$mail_from_name} <{$mail_from}>\r\n";
    $headers .= "MIME-Version: 1.0\r\nContent-type: text/html; charset=utf-8\r\n";
    return mail($to, $subject, $body, $headers);
}

function gen_token($len=32){
    return bin2hex(random_bytes($len));
}

function log_activity($user_id, $action){
    global $conn;
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $stmt = $conn->prepare("INSERT INTO activity_logs (user_id, action, ip, user_agent) VALUES (?,?,?,?)");
    $stmt->bind_param("isss",$user_id, $action, $ip, $ua);
    $stmt->execute();
}
?>
