<?php
session_start();
require_once "functions.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role']!=='admin') {
    header("Location: login.php"); exit;
}
$res = $conn->query("SELECT id,name,email,role,is_verified,created_at FROM users ORDER BY created_at DESC");
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin</title>
<link rel="stylesheet" href="assets/style.css"></head><body>
<div class="form-box">
  <h2>Admin - Users</h2>
  <table style="width:100%;border-collapse:collapse">
    <tr><th>#</th><th>Name</th><th>Email</th><th>Role</th><th>Verified</th><th>Joined</th></tr>
    <?php while($u = $res->fetch_assoc()): ?>
      <tr>
        <td><?=esc($u['id'])?></td>
        <td><?=esc($u['name'])?></td>
        <td><?=esc($u['email'])?></td>
        <td><?=esc($u['role'])?></td>
        <td><?= $u['is_verified'] ? 'Yes' : 'No' ?></td>
        <td><?=esc($u['created_at'])?></td>
      </tr>
    <?php endwhile; ?>
  </table>
  <p><a href="dashboard.php">Back</a></p>
</div>
</body></html>
