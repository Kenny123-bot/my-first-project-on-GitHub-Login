<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html><html><head>
<title>Dashboard</title>
<link rel="stylesheet" href="style.css">
</head><body>
<div class="dashboard">
<h1>Welcome, <?= $_SESSION['user']; ?> 👋</h1>
<p>You are logged in successfully.</p>
<a href="logout.php" class="logout-btn">Logout</a>
</div>
</body></html>